﻿namespace BusinessDataLAyer
{
    public class Class1
    {

    }
}